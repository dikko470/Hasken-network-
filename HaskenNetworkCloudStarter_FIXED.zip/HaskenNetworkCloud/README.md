# HASKEN NETWORK
A minimal Android project starter configured for GitHub Actions APK builds. This is a buildable UI starter only; offline radio messaging, mesh relay, and encryption are not implemented yet.
